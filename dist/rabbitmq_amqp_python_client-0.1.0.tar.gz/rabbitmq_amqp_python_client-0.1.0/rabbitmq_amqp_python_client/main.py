import optparse
from proton import Message
from proton.handlers import MessagingHandler
from proton.reactor import Container
import tornado.ioloop
import tornado.web
from tornado.gen import coroutine
from tornado.concurrent import Future

class Send(MessagingHandler):
    def __init__(self, url):
        super(Send, self).__init__()
        self.url = url
        self.confirmed = 0
        self.pending = []
        self.sender = None

    def on_start(self, event):
        print("start")
        self.sender = event.create_sender(self.url)



    def on_sendable(self, event):

        while event.sender.credit and self.pending:
            msg = self.pending.pop()
            event.sender.send(msg)

    def do_request(self):
        print("im here")
        if self.pending and self.sender.credit:
            kv = {}
            kv["auto_delete"] = "false"
            kv["durable"] = "true"
            kv["type"] = "direct"
            kv["INTERNAL"] = "false"
            kv["arguments"] = {}

            msg = Message(
                id='1',
                body=kv,
                reply_to='$me',
                address='/exchanges/XXXXXXX',
                properties={'MessageID': 'b2197e27-1f88-495d-937f-1f78941120c2', 'ReplyTo': '$me', 'To': '/exchanges/XXXXXXX', 'Subject': 'PUT'})
            self.pending.append(msg)



    def on_accepted(self, event):
        event.connection.close()
        #self.confirmed += 1
        #if self.confirmed == self.total:
        #    print ("all messages confirmed")
        #    event.connection.close()

    def on_disconnected(self, event):
        self.sent = self.confirmed

def main():

    try:
        Container(Send("amqp://guest:guest@localhost:5672")).run()
    except KeyboardInterrupt:
        pass

    print("im there")







if __name__ == '__main__':
  main()